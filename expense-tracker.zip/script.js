let expenses = JSON.parse(localStorage.getItem('expenses')) || [];

function saveExpenses() {
  localStorage.setItem('expenses', JSON.stringify(expenses));
}

function addExpense() {
  const name = document.getElementById('expenseName').value.trim();
  const amount = parseFloat(document.getElementById('expenseAmount').value);
  const category = document.getElementById('expenseCategory').value;

  if (!name || isNaN(amount) || amount <= 0) {
    alert('Please enter valid name and amount!');
    return;
  }

  expenses.push({
    id: Date.now(),
    name,
    amount,
    category
  });

  document.getElementById('expenseName').value = '';
  document.getElementById('expenseAmount').value = '';
  document.getElementById('expenseCategory').value = 'Food';
  saveExpenses();
  renderExpenses();
}

function deleteExpense(id) {
  expenses = expenses.filter(e => e.id !== id);
  saveExpenses();
  renderExpenses();
}

function renderExpenses() {
  const list = document.getElementById('expensesList');
  list.innerHTML = '';

  const filter = document.getElementById('categoryFilter').value;
  let total = 0;

  expenses.forEach(exp => {
    if (filter !== 'All' && exp.category !== filter) return;
    total += exp.amount;

    const div = document.createElement('div');
    div.className = 'expense';
    div.innerHTML = \`
      <button onclick="deleteExpense(\${exp.id})">X</button>
      <h4>\${exp.name}</h4>
      <div class="amount">$\${exp.amount.toFixed(2)}</div>
      <div class="category">\${exp.category}</div>
    \`;
    list.appendChild(div);
  });

  document.getElementById('totalAmount').innerText = total.toFixed(2);
}

function toggleTheme() {
  document.body.classList.toggle('dark');
  localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
}

if (localStorage.getItem('theme') === 'dark') {
  document.body.classList.add('dark');
}

renderExpenses();
